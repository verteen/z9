
from z9.core.exceptions import CommonException

class NewException(CommonException):
    pass